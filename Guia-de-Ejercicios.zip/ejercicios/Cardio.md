# Ejercicio Cardio

## Descripción
Los ejercicios de cardio son actividades que aumentan tu frecuencia cardíaca y mejoran la resistencia.

## Beneficios
- Aumenta la capacidad cardiovascular.
- Ayuda a quemar calorías.
- Mejora el estado de ánimo.

## Instrucciones
1. Comienza con un calentamiento de 5-10 minutos.
2. Realiza la actividad (correr, nadar, andar en bicicleta) durante al menos 30 minutos.
3. Termina con un enfriamiento y estiramientos.

## Consejos
- Mantén una hidratación adecuada.
- Escoge un ritmo que puedas mantener.